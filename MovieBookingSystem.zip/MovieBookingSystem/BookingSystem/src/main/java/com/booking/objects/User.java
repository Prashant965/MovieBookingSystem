package com.booking.objects;

import lombok.Builder;
import lombok.Data;

import jakarta.persistence.*;

@Builder
@Data
@Entity
@Table(name = "User1")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String password;

    public Object getPassword() {
        return password;
    }

    // Constructors, getters, and setters
}

