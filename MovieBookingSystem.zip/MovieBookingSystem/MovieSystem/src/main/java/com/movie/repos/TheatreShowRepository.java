package com.movie.repos;


import com.movie.objects.Show;
import com.theatre.objects.TheatreShow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface TheatreShowRepository extends JpaRepository<Show, Long> {

    List<Show> findByMovieIdAndShowDateTime(Long movieId, Date date);
}
