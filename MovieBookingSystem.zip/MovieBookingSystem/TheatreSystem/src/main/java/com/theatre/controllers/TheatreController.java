package com.theatre.controllers;

import com.theatre.objects.Show;
import com.theatre.service.TheatreService;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/theatres")
public class TheatreController {
    private final TheatreService theatreService;

    public TheatreController(TheatreService theatreService) {
        this.theatreService = theatreService;
    }

    @PostMapping("/shows")
    public Long createShow(@RequestBody Show show) {
        return theatreService.createShow(show);
    }

    @PutMapping("/shows")
    public Long updateShow(@RequestBody Show show) {

        return theatreService.updateShow(show);
    }

    @DeleteMapping("/shows/{showId}")
    public void deleteShow(@PathVariable String showId) {
        theatreService.deleteShow(showId);
    }

    @GetMapping("/shows/")
    public List<Show> searchShow() {
        return theatreService.getAllShows();
    }
}
